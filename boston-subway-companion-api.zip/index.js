"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var packagejson = require('./package.json');
const routes_1 = require("./lib/routes");
const models_1 = require("./lib/models");
const constants_1 = require("./lib/constants");
const vehicles_1 = require("./lib/routes/vehicles");
const polylines_1 = require("./lib/routes/polylines");
const timeBetweenWalk_1 = require("./lib/routes/timeBetweenWalk");
console.log('loaded ' + packagejson.name + ', version ' + packagejson.version);
const test = async () => console.log(await routes_1.nearest({ latitude: 42.7654, longitude: -71.4676 }));
test();
exports.handler = async function (event, context) {
    if (!event.path) {
        return { statusCode: 404, body: '' };
    }
    if (event.path.includes('/stops/nearest')) {
        const error = handleLocationParams(event);
        if (error) {
            return error;
        }
        const list = await routes_1.nearest(event.queryStringParameters);
        if (JSON.parse(list).error) {
            return { statusCode: 500, body: list };
        }
        return { statusCode: 200, body: list };
    }
    if (event.path.includes('/stops/allnearby')) {
        const error = handleLocationParams(event);
        if (error) {
            return error;
        }
        const list = await routes_1.allNearby(event.queryStringParameters, Number(event.queryStringParameters.range));
        if (JSON.parse(list).error) {
            return { statusCode: 500, body: list };
        }
        return { statusCode: 200, body: list };
    }
    if (event.path.includes('/stops/location')) {
        if (!event.body) {
            return {
                statusCode: 400,
                body: models_1.makeError('No stop provided in request body', 'Cannot load stop')
            };
        }
        const list = await routes_1.stopsAtSameLocation(JSON.parse(event.body));
        if (JSON.parse(list).error) {
            return { statusCode: 500, body: list };
        }
        return { statusCode: 200, body: list };
    }
    if (event.path.includes('/stops/alerts')) {
        if (!event.queryStringParameters || !event.queryStringParameters.stopId) {
            return {
                statusCode: 400,
                body: models_1.makeError('stopId parameter not provided', 'Cannot load stop')
            };
        }
        const list = await routes_1.alertsForStop(JSON.parse(event.queryStringParameters.stopId));
        if (JSON.parse(list).error) {
            return { statusCode: 500, body: list };
        }
        return { statusCode: 200, body: list };
    }
    if (event.path.includes('/stops/neighbor')) {
        if (!event.queryStringParameters || !event.queryStringParameters.stopId) {
            return {
                statusCode: 400,
                body: models_1.makeError(constants_1.stopIdParamsError, constants_1.standardUserError)
            };
        }
        const stop = await routes_1.neighborStop(JSON.parse(event.queryStringParameters.stopId));
        if (JSON.parse(stop).error) {
            return { statusCode: 500, body: stop };
        }
        return { statusCode: 200, body: stop };
    }
    if (event.path.includes('/stops/direction')) {
        if (!event.queryStringParameters ||
            !event.queryStringParameters.stop1Name ||
            !event.queryStringParameters.stop2Name) {
            return {
                statusCode: 400,
                body: models_1.makeError(constants_1.stopIdParamsError, constants_1.standardUserError)
            };
        }
        const endStopName = await routes_1.direction(event.queryStringParameters.stop1Name, event.queryStringParameters.stop2Name);
        if (JSON.parse(endStopName).error) {
            return { statusCode: 500, body: endStopName };
        }
        return { statusCode: 200, body: endStopName };
    }
    if (event.path.includes('/stops/timebetween') && !event.path.includes('/stops/timebetweenwalk')) {
        if (!event.queryStringParameters ||
            !event.queryStringParameters.stop1Name ||
            !event.queryStringParameters.stop2Name) {
            return {
                statusCode: 400,
                body: models_1.makeError(constants_1.stopIdParamsError, constants_1.standardUserError)
            };
        }
        const minutes = await routes_1.timeBetweenStops(event.queryStringParameters.stop1Name, event.queryStringParameters.stop2Name);
        if (JSON.parse(minutes).error) {
            return { statusCode: 500, body: minutes };
        }
        return { statusCode: 200, body: minutes };
    }
    if (event.path.includes('/stops/timebetweenwalk')) {
        const error = handleLocationParams(event);
        if (error || !event.queryStringParameters || !event.queryStringParameters.stopName) {
            return {
                statusCode: 400,
                body: models_1.makeError(constants_1.stopNameParamsError, constants_1.standardUserError)
            };
        }
        const minutes = await timeBetweenWalk_1.timeBetweenWalk(event.queryStringParameters.stopName, event.queryStringParameters.latitude, event.queryStringParameters.longitude);
        if (JSON.parse(minutes).error) {
            return { statusCode: 500, body: minutes };
        }
        return { statusCode: 200, body: minutes };
    }
    if (event.path.includes('/vehicles')) {
        const list = await vehicles_1.vehicles();
        if (JSON.parse(list).error) {
            return { statusCode: 500, body: list };
        }
        return { statusCode: 200, body: list };
    }
    if (event.path.includes('/polylines')) {
        const list = await polylines_1.polylines();
        if (JSON.parse(list).error) {
            return { statusCode: 500, body: list };
        }
        return { statusCode: 200, body: list };
    }
    return { statusCode: 404, body: models_1.makeError(constants_1.noMatchingRouteError, constants_1.standardUserError) };
};
const handleLocationParams = (event) => {
    if (!event.queryStringParameters ||
        !event.queryStringParameters.latitude ||
        !event.queryStringParameters.longitude) {
        return {
            statusCode: 400,
            body: models_1.makeError(constants_1.missingLocationParamsError, constants_1.standardUserError)
        };
    }
    return null;
};
