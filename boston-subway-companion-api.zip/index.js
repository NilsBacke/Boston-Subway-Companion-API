"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var packagejson = require('./package.json');
const routes_1 = require("./lib/routes");
const models_1 = require("./lib/models");
const constants_1 = require("./lib/constants");
console.log('loaded ' + packagejson.name + ', version ' + packagejson.version);
exports.handler = async function (event, context) {
    if (!event.path) {
        return { statusCode: 404, body: '' };
    }
    if (event.path.includes('/stops/nearest')) {
        const error = handleLocationParams(event);
        if (error) {
            return error;
        }
        const list = await routes_1.nearest(event.queryStringParameters);
        return { statusCode: 200, body: list };
    }
    if (event.path.includes('/stops/allnearby')) {
        const error = handleLocationParams(event);
        if (error) {
            return error;
        }
        const list = await routes_1.allNearby(event.queryStringParameters, Number(event.queryStringParameters.range));
        return { statusCode: 200, body: list };
    }
    if (event.path.includes('/stops/location')) {
        if (!event.body) {
            return {
                statusCode: 400,
                body: models_1.makeError('No stop provided in request body', 'Cannot load stop')
            };
        }
        const list = await routes_1.stopsAtSameLocation(JSON.parse(event.body));
        return { statusCode: 200, body: list };
    }
    if (event.path.includes('/stops/alerts')) {
        if (!event.queryStringParameters || !event.queryStringParameters.stopId) {
            return {
                statusCode: 400,
                body: models_1.makeError('stopId parameter not provided', 'Cannot load stop')
            };
        }
        const list = await routes_1.alertsForStop(JSON.parse(event.queryStringParameters.stopId));
        return { statusCode: 200, body: list };
    }
    if (event.path.includes('/stops/neighbor')) {
        if (!event.queryStringParameters || !event.queryStringParameters.stopId) {
            return {
                statusCode: 400,
                body: models_1.makeError(constants_1.stopIdParamsError, constants_1.standardUserError)
            };
        }
        const stop = await routes_1.neighborStop(JSON.parse(event.queryStringParameters.stopId));
        return { statusCode: 200, body: stop };
    }
    if (event.path.includes('/stops/direction')) {
        if (!event.queryStringParameters ||
            !event.queryStringParameters.stop1Name ||
            !event.queryStringParameters.stop2Name) {
            return {
                statusCode: 400,
                body: models_1.makeError(constants_1.stopIdParamsError, constants_1.standardUserError)
            };
        }
        const endStopName = await routes_1.direction(event.queryStringParameters.stop1Name, event.queryStringParameters.stop2Name);
        return { statusCode: 200, body: endStopName };
    }
    if (event.path.includes('/stops/timebetween')) {
        if (!event.queryStringParameters ||
            !event.queryStringParameters.stop1Name ||
            !event.queryStringParameters.stop2Name) {
            return {
                statusCode: 400,
                body: models_1.makeError(constants_1.stopIdParamsError, constants_1.standardUserError)
            };
        }
        const minutes = await routes_1.timeBetween(event.queryStringParameters.stop1Name, event.queryStringParameters.stop2Name);
        return { statusCode: 200, body: minutes };
    }
    return { statusCode: 404, body: models_1.makeError(constants_1.noMatchingRouteError, constants_1.standardUserError) };
};
const handleLocationParams = (event) => {
    if (!event.queryStringParameters ||
        !event.queryStringParameters.latitude ||
        !event.queryStringParameters.longitude) {
        return {
            statusCode: 400,
            body: models_1.makeError(constants_1.missingLocationParamsError, constants_1.standardUserError)
        };
    }
    return null;
};
