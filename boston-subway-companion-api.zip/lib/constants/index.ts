export const northList: string[] = ['Alewife', 'Oak Grove']
export const southList: string[] = ['Ashmont/Braintree', 'Ashmont', 'Braintree', 'Forest Hills', 'Mattapan']
export const westList: string[] = [
	'Bowdoin',
	'Boston College',
	'Cleveland Circle',
	'Riverside',
	'Heath Street',
	'Cleveland Circle/Riverside'
]
export const eastList: string[] = ['Wonderland', 'Park Street', 'North Station', 'Government Center', 'Lechmere']
