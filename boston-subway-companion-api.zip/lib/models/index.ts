export { Stop } from './stop'

export interface Location {
	latitude: string
	longitude: string
}
