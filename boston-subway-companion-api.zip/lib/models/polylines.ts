export interface Polyline {
	lineTitle: string
	color: string
	polyline: string
}
