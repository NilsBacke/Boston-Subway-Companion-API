export const apiKey = 'dc44b30101114e88b45041a4a9b65e06'
export const baseURL = 'https://api-v3.mbta.com'
